define(['romania'], function (Romania) {
    return {};
});
